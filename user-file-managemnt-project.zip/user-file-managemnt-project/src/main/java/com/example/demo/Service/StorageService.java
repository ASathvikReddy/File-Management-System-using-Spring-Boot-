package com.example.demo.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.IOUtils;

@Service
public class StorageService {

    private static final Logger log = LoggerFactory.getLogger(StorageService.class);

    @Value("${application.bucket.name}")
    private String bucketName;

    @Autowired
    private AmazonS3 s3client;

    // Upload file to a specific user folder
    public String uploadFile(MultipartFile file, String folder) {
        File fileObj = convertMultiPartFileToFile(file);
        String fileName = folder + System.currentTimeMillis() + "_" + file.getOriginalFilename();
        try {
            s3client.putObject(new PutObjectRequest(bucketName, fileName, fileObj));
            log.info("File uploaded successfully: {}", fileName);
        } catch (Exception e) {
            log.error("Error uploading file to S3: {}", e.getMessage(), e);
            throw new RuntimeException("Error uploading file", e);
        } finally {
            if (fileObj.exists()) {
                fileObj.delete();
            }
        }
        return "File uploaded: " + fileName;
    }

    // Download file from a specific user folder
    public byte[] downloadFile(String fileName) {
        try {
            log.info("Attempting to download file: {}", fileName);
            S3Object s3Object = s3client.getObject(bucketName, fileName); // Ensure full path is provided
            S3ObjectInputStream inputStream = s3Object.getObjectContent();
            byte[] content = IOUtils.toByteArray(inputStream);
            log.info("File downloaded successfully: {}", fileName);
            return content;
        } catch (AmazonS3Exception e) {
            log.error("S3 error: {}", e.getMessage(), e);
            throw new RuntimeException("Error fetching file from S3: " + fileName, e);
        } catch (IOException e) {
            log.error("I/O error: {}", e.getMessage(), e);
            throw new RuntimeException("Error reading file: " + fileName, e);
        }
    }

    // Delete file from a specific user folder
    public String deleteFile(String fileName) {
        try {
            s3client.deleteObject(bucketName, fileName);
            log.info("File deleted successfully: {}", fileName);
            return fileName + " removed...";
        } catch (Exception e) {
            log.error("Error deleting file: {}", e.getMessage(), e);
            throw new RuntimeException("Error deleting file", e);
        }
    }

    // List all files in a user's folder
    public List<String> listFiles(String folder) {
        try {
            ListObjectsV2Request request = new ListObjectsV2Request()
                .withBucketName(bucketName)
                .withPrefix(folder);  // Make sure folder path is correctly specified

            ListObjectsV2Result result = s3client.listObjectsV2(request);
            return result.getObjectSummaries()
                .stream()
                .map(S3ObjectSummary::getKey)
                .filter(key -> !key.endsWith("/"))  // Filter out folders (if any)
                .collect(Collectors.toList());
        } catch (AmazonS3Exception e) {
            log.error("S3 error while listing files: {}", e.getMessage(), e);
            throw new RuntimeException("Error listing files from S3", e);
        }
    }


    // Convert MultipartFile to File
    private File convertMultiPartFileToFile(MultipartFile file) {
        File convFile = new File(file.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convFile)) {
            fos.write(file.getBytes());
        } catch (IOException e) {
            log.error("Error converting MultipartFile to File", e);
            throw new RuntimeException("Error converting MultipartFile to File", e);
        }
        return convFile;
    }

}
