//package com.example.demo.Controller;
//
//import java.security.Principal;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.io.ByteArrayResource;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.example.demo.Service.StorageService;
//
//@Controller
//public class StorageController {
//
//    @Autowired
//    private StorageService service;
//
//    @GetMapping("/")
//    public String loginPage() {
//        return "login";
//    }
//
//    @GetMapping("/main")
//    public String mainPage(Model model, Principal principal) {
//        String username = principal.getName(); // Fetch authenticated user's name/email
//        List<String> files = service.listFiles(username); // Implement in `StorageService` to list user files
//        model.addAttribute("username", username);
//        model.addAttribute("files", files);
//        return "main";
//    }
//
//    @PostMapping("/upload")
//    public String uploadFile(@RequestParam("file") MultipartFile file, Principal principal, Model model) {
//        String username = principal.getName();
//        String folder = username + "/"; // Create a unique folder in S3 for the user
//        String message;
//        try {
//            message = service.uploadFile(file, folder); // Modify `uploadFile` to accept a folder
//        } catch (Exception e) {
//            message = "Failed to upload file: " + e.getMessage();
//        }
//        model.addAttribute("message", message);
//        return "redirect:/main";
//    }
//
//    @GetMapping("/download/{fileName}")
//    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable String fileName, Principal principal) {
//        String username = principal.getName();
//        String folder = username + "/"; // Fetch the user's folder
//        byte[] data = service.downloadFile(folder + fileName); // Adjust `downloadFile` for folder structure
//        ByteArrayResource resource = new ByteArrayResource(data);
//        return ResponseEntity
//                .ok()
//                .contentLength(data.length)
//                .header("Content-type", "application/octet-stream")
//                .header("Content-disposition", "attachment; filename=\"" + fileName + "\"")
//                .body(resource);
//    }
//
//    @PostMapping("/delete/{fileName}")
//    public String deleteFile(@PathVariable String fileName, Principal principal) {
//        String username = principal.getName();
//        String folder = username + "/"; // Fetch the user's folder
//        service.deleteFile(folder + fileName); // Adjust `deleteFile` for folder structure
//        return "redirect:/main";
//    }
//}

package com.example.demo.Controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.Service.StorageService;

@Controller
public class StorageController {

    @Autowired
    private StorageService service;

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/main")
    public String mainPage(Model model, Principal principal) {
        String username = principal.getName(); // Fetch authenticated user's name/email
        List<String> files = service.listFiles(username); // List files in user-specific folder
        model.addAttribute("username", username);
        model.addAttribute("files", files);
        return "main";
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file, Principal principal, Model model) {
        String username = principal.getName(); // Get the authenticated user
        String message = service.uploadFile(file, username); // Upload the file to user-specific folder
        model.addAttribute("message", message);
        return "redirect:/main"; // Redirect back to the main page after upload
    }

    @GetMapping("/download/{fileName}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable String fileName) {
        byte[] data = service.downloadFile(fileName);
        ByteArrayResource resource = new ByteArrayResource(data);
        return ResponseEntity
                .ok()
                .contentLength(data.length)
                .header("Content-type", "application/octet-stream")
                .header("Content-disposition", "attachment; filename=\"" + fileName + "\"")
                .body(resource);
    }

    @PostMapping("/delete/{fileName}")
    public String deleteFile(@PathVariable String fileName, Model model) {
        service.deleteFile(fileName); // Delete the file
        return "redirect:/main"; // Redirect back to the main page after deletion
    }
}
